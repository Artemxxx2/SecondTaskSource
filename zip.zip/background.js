chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        if(request.newIconPath == 0){
            chrome.browserAction.setIcon({
                path: {
                    16: "disabled.png",
                    48: "disabled.png",
                    128: "disabled.png" 
                }
            });
        } else {
            chrome.browserAction.setIcon({
                path: {
                    16: "16.png",
                    48: "48.png",
                    128: "128.png" 
                }
            });
        }
    }
);