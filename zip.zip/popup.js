document.addEventListener("DOMContentLoaded", function() {
  document.getElementById("update").addEventListener("click", function popup() {
    chrome.tabs.query({currentWindow: true, active: true}, function (tabs){
      var activeTab = tabs[0];
      chrome.tabs.sendMessage(activeTab.id, {"message": document.getElementById("email").value});
      localStorage['email'] = document.getElementById("email").value;
      document.getElementById("current_email").innerHTML = localStorage['email'];
   });
  });
});

window.onfocus = function(){
  if(localStorage['email'] != undefined){
    document.getElementById("current_email").innerHTML = localStorage['email'];
    chrome.tabs.query({currentWindow: true, active: true}, function (tabs){
      var activeTab = tabs[0];
      chrome.tabs.sendMessage(activeTab.id, {"message": localStorage['email']});
      document.getElementById("current_email").innerHTML = localStorage['email'];
    });
  }
}