sessionStorage.removeItem('email');
chrome.runtime.sendMessage({ "newIconPath" : 0 });
chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        chrome.runtime.sendMessage({ "newIconPath" : 1 });
        if(sessionStorage['email'] != request.message){
            var script = document.createElement('script'); 
            script.src = chrome.extension.getURL('inject.js');
            script.onload = function() {
                window.postMessage({ 
                    type: "FROM_MY_EXTENSIONS", 
                    value: request.message },
                    "*");
            }
            document.body.appendChild(script);
            sessionStorage['email'] = request.message;
        }
    }
);