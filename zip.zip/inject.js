window.addEventListener("message", function(event) {
    if(event.data.type === 'FROM_MY_EXTENSIONS') {
        window.email = event.data.value;
	    var origOpen = XMLHttpRequest.prototype.open;
	    XMLHttpRequest.prototype.open = function(method, url, async, user, pass) {
			let param = "?email=";
			let position = url.indexOf(param);
			if(position != -1){
				url = url.substring(0, position+param.length)+email;
			}
				this.addEventListener('load', function() {
				});
				origOpen.apply(this, arguments);
		};
    }
}, false);